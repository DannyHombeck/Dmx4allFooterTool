<?php declare(strict_types=1);

/*
 * Dienste als PHP statt XML: Shopware 6.8 (Symfony 8) laedt keine
 * services.xml mehr. Shopware 6.7 laedt services.php ebenfalls, damit
 * funktioniert diese Datei in beiden Versionen.
 */

namespace Symfony\Component\DependencyInjection\Loader\Configurator;

use Dmx4allFooterTool\Core\Content\Layout\LayoutDefinition;
use Dmx4allFooterTool\Service\LayoutService;
use Dmx4allFooterTool\Twig\FooterToolExtension;
use Doctrine\DBAL\Connection;
use Shopware\Core\System\SystemConfig\SystemConfigService;

return static function (ContainerConfigurator $container): void {
    $services = $container->services();

    $services->set(LayoutDefinition::class)
        ->public()
        ->tag('shopware.entity.definition', ['entity' => 'dmx4all_footer_tool_layout']);

    $services->set(LayoutService::class)
        ->args([
            service(Connection::class),
            service(SystemConfigService::class),
            service('media.repository'),
            '%kernel.shopware_version%',
        ]);

    $services->set(FooterToolExtension::class)
        ->args([
            service(LayoutService::class),
            service('request_stack'),
        ])
        ->tag('twig.extension');
};
